package autotests.e2e;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import autotests.BaseTest;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

import static autotests.BaseTest.driver;

public class E2ETest extends BaseTest{

    private static int index = 0;

    @BeforeMethod
    public void openRadioButtonPage(){
        scrollTo();

        formsPage.clickOnFormsSection();
        formsPage.pracFormSection();
        scrollTo();
    }


    //dependOnMethods = "";
//    @Ignore
    @Test(invocationCount = 1)
    public void CheckFormsAndWebTablesFunctionality() {

        String firstName = "Name" + index++;
        String lastName = "Last name" + index;
        String mobileNumber = "12345678";
        String email = "test" + index + "@gmail.com";
        String age = "20";
        String salary = "4200";
        String department = "AQA Dep";


        formsPage.setfName(firstName);
        formsPage.setlName(lastName);
        formsPage.selectGenderMale();
        formsPage.setPhoneNumber(mobileNumber);
        scrollTo();
        scrollTo();
        formsPage.clickOnSubmit();

        openHomePage();

        scrollTo();
        webTablesPage.clickOnElementsSection();
        webTablesPage.clickOnWebTablesSection();
        scrollTo();

        webTablesPage.userRegistration(firstName, lastName, email, age, salary, department);

    }
}
