package autotests;

import framework.book_store_application.BookStorePage;
import framework.book_store_application.ProfilePage;
import framework.book_store_application.RegisterPage;
import framework.cases.Cases;
import framework.constants.Data;
import framework.pages.BasePage;
import framework.pages.elements.*;
import framework.pages.forms.FormsPage;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import framework.pages.forms.PracticeFormPage;
public class BaseTest {

    private static ChromeDriver chromeDriver;
    private JavascriptExecutor executor;
    protected Data data;
    protected TextBoxPage textBoxPage;
    protected RadioButtonsPage radioButtonsPage;
    protected CheckBoxPage checkBoxPage;
    protected WebTablesPage webTablesPage;
    protected ButtonsPage buttonsPage;
    protected PracticeFormPage practiceFormPage;
    protected FormsPage formsPage;
    protected Cases cases;
    protected ProfilePage profilePage;
    protected BookStorePage bookStorePage;
    protected RegisterPage registerPage;

    public BaseTest() {
        WebDriverManager.chromedriver().setup();

        chromeDriver = new ChromeDriver();
        textBoxPage = new TextBoxPage(chromeDriver);
        radioButtonsPage = new RadioButtonsPage(chromeDriver);
        checkBoxPage = new CheckBoxPage(chromeDriver);
        webTablesPage = new WebTablesPage(chromeDriver);
        buttonsPage = new ButtonsPage(chromeDriver);
        practiceFormPage = new PracticeFormPage(chromeDriver);
        formsPage = new FormsPage(chromeDriver);
        cases = new Cases(chromeDriver);
        profilePage = new ProfilePage(chromeDriver);
        bookStorePage = new BookStorePage(chromeDriver);
        registerPage = new RegisterPage(chromeDriver);
        data = new Data();
        executor = (JavascriptExecutor) chromeDriver;
    }

    public static ChromeDriver driver() {
        return chromeDriver;
    }

    public void scrollTo() {
        executor.executeScript("window.scrollBy(0, 200)", "");
    }

    public void openHomePage() {
        chromeDriver.get(data.getBaseUrl());
    }

    @BeforeMethod(alwaysRun = true)
    public void openBaseUrl() {
        driver().manage().window().maximize();
        driver().get(data.getBaseUrl());
    }

//    @AfterMethod(alwaysRun = true)
//    public void closeDriver() {
//        driver().close();
//    }
    @AfterSuite(alwaysRun = true)
    public void closeDriver() {
        driver().close();
    }


//    @AfterSuite(alwaysRun = true)
//    public void quitDriver() {
//        driver().quit();
//    }
}
