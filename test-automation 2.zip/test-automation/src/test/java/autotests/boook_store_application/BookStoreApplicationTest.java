package autotests.boook_store_application;

import autotests.BaseTest;
import framework.helpers.WaitHelper;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static framework.constants.Data.WRONG_PASSWORD;
import static java.sql.DriverManager.getDriver;

public class BookStoreApplicationTest extends BaseTest {

    @BeforeMethod
    public void openProfilePage() {
        scrollTo();
        scrollTo();
        bookStorePage.clickOnBookStoreApplicationSection();
        scrollTo();
        scrollTo();
        bookStorePage.clickOnProfileButton();
        scrollTo();
    }

    @Test
    public void checkBookStoreRegistrationFlow() throws InterruptedException {
        profilePage
                .verifyNotLoggedInMessage()
                .clickOnRegisterLink(driver())
                .verifyAllUIElements()
                .fillAllFields("Ashot", "Azganun", "Ashot001", WRONG_PASSWORD);
        scrollTo();
        scrollTo();
        scrollTo();
                registerPage
                        .tryAcceptCaptcha(driver())
                        .clickOnRegisterButton();

    }
}
