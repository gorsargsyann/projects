package autotests.forms;

import autotests.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;

public class PracticeFormTest extends BaseTest {

    @Test
    public void practiceFormTest() throws InterruptedException {
        practiceFormPage.clickOnFormsSection();
        practiceFormPage.clickOnPracticeFormSection();

        Assert.assertTrue(driver().getCurrentUrl().endsWith(practiceFormPage.getPracticeFormPagePath()));
        scrollTo();

        practiceFormPage.inputFirstName();
        practiceFormPage.inputLastName();
        practiceFormPage.selectGender();
        practiceFormPage.inputMobile();
        practiceFormPage.clickOnDateOfBirthBtn();
        practiceFormPage.selectYear();
        practiceFormPage.selectMonth();
        practiceFormPage.selectDay();
        scrollTo();
        practiceFormPage.inputSubjects();
        practiceFormPage.selectHobbies();
        practiceFormPage.inputPicture();
        practiceFormPage.inputCurrentAddress();
        scrollTo();
        practiceFormPage.selectState();
        practiceFormPage.selectNCR();
        practiceFormPage.selectCity();
        practiceFormPage.selectGurgaon();
        practiceFormPage.clickSubmitBtn();
    }
}
