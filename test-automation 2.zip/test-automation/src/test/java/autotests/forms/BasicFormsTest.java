package autotests.forms;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.util.List;

public class BasicFormsTest {
    public static void main(String[] args) throws InterruptedException{

        WebDriverManager.chromedriver().setup();
        ChromeDriver chromeDriver = new ChromeDriver();

        JavascriptExecutor executor = (JavascriptExecutor) chromeDriver;
        PageFactory.initElements(chromeDriver, new BasicFormsTest());

        chromeDriver.get("https://demoqa.com/");
        chromeDriver.manage().window().maximize();

        Thread.sleep(5000);
        chromeDriver.findElementByXPath("//*[text() = 'Forms']").click();

        Thread.sleep(5000);
        Assert.assertTrue(chromeDriver
                .findElementByXPath("//*[text() = 'Please select an item from left to start practice.']")
                .isDisplayed());

        Assert.assertTrue(chromeDriver.getCurrentUrl().endsWith("forms"));

        chromeDriver.findElementByXPath("//*[text() = 'Practice Form']").click();

        WebElement firstNameInput = chromeDriver.findElementById("firstName");
        WebElement lastNameInput = chromeDriver.findElementById("lastName");
        WebElement emailInput = chromeDriver.findElementById("userEmail");
        WebElement Gender = chromeDriver.findElement(By.cssSelector("#genterWrapper > div.col-md-9.col-sm-12"));//check
        WebElement maleInput = chromeDriver.findElement(By.cssSelector("[for = 'gender-radio-1'"));
        WebElement femaleInput = chromeDriver.findElement(By.cssSelector("[for = 'gender-radio-2'"));
        WebElement otherInput = chromeDriver.findElement(By.cssSelector("[for = 'gender-radio-3'"));
        WebElement mobileInput = chromeDriver.findElementById("userNumber");
        WebElement dateOfBirthInput = chromeDriver.findElementById("dateOfBirthInput");
        WebElement subjectsInput = chromeDriver.findElementById("subjectsInput");
        WebElement Hobbies = chromeDriver.findElement(By.cssSelector("#hobbiesWrapper > div.col-md-9.col-sm-12"));//check
        WebElement sportsInput = chromeDriver.findElement(By.cssSelector("#hobbiesWrapper > div.col-md-9.col-sm-12 > div:nth-child(1) > label"));
        WebElement readingInput = chromeDriver.findElement(By.cssSelector("#hobbiesWrapper > div.col-md-9.col-sm-12 > div:nth-child(2) > label"));
        WebElement musicInput = chromeDriver.findElement(By.cssSelector("#hobbiesWrapper > div.col-md-9.col-sm-12 > div:nth-child(3) > label"));
        WebElement pictureInput = chromeDriver.findElementById("uploadPicture");
        WebElement currentAddressInput = chromeDriver.findElementById("currentAddress");
        WebElement stateInput = chromeDriver.findElement(By.cssSelector("#state > div > div.css-1wy0on6 > div > svg"));
        WebElement cityInput = chromeDriver.findElement(By.cssSelector("#city > div > div.css-1wy0on6 > div > svg"));
        WebElement submitButton = chromeDriver.findElementById("submit");


        executor.executeScript("window.scrollBy(0, 150)", "");
        Assert.assertTrue(firstNameInput.isDisplayed());
        Assert.assertTrue(lastNameInput.isDisplayed());
        Assert.assertTrue(emailInput.isDisplayed());
        Assert.assertTrue(Gender.isDisplayed());
        Assert.assertTrue(mobileInput.isDisplayed());
        Assert.assertTrue(dateOfBirthInput.isDisplayed());
        Assert.assertTrue(subjectsInput.isDisplayed());
        Assert.assertTrue(Hobbies.isDisplayed());
        Assert.assertTrue(pictureInput.isDisplayed());
        Assert.assertTrue(currentAddressInput.isDisplayed());
        Assert.assertTrue(stateInput.isDisplayed());


        firstNameInput.sendKeys("Gor");
        lastNameInput.sendKeys("Sargsyan");
        emailInput.sendKeys("test@gmail.com");
        mobileInput.sendKeys("0123321321123");
        maleInput.click();


        executor.executeScript("window.scrollBy(0, 150)", "");

//BIRTH DATA
        dateOfBirthInput.click();
        Thread.sleep(2000);

        WebElement monthSelect = chromeDriver.findElementByCssSelector(".react-datepicker__month-select");
        WebElement yearSelect = chromeDriver.findElementByCssSelector(".react-datepicker__year-select");

//        WebElement firstDayOfMonth = chromeDriver.findElementByXPath("//*[text() = '1']");
//        firstDayOfMonth.click();

        Select select = new Select(monthSelect);
        select.selectByVisibleText("June");

        new Select(yearSelect).selectByValue("1990");

        List<WebElement> days = chromeDriver.findElementsByCssSelector(".react-datepicker__day");

        days.get(2).click();


//Subjects
        subjectsInput.sendKeys("Eng");
        subjectsInput.sendKeys(Keys.ENTER);

//Hobbies
        sportsInput.click();
        musicInput.click();

//Picture
        pictureInput.sendKeys("/Users/gorsargsyan/Downloads/7960611f-9837-452e-9c9e-3ba3c9fb01e4.png");
        executor.executeScript("window.scrollBy(0, 200)", "");

//Address
        currentAddressInput.sendKeys("Yerevan, Armenia");

//STATE AND CITY
        chromeDriver.findElementByXPath("//*[text() = 'Select State']").click();
        chromeDriver.findElementByXPath("//*[text() = 'NCR']").click();

        chromeDriver.findElementByXPath("//*[text() = 'Select City']").click();
        chromeDriver.findElementByXPath("//*[text() = 'Gurgaon']").click();



        submitButton.click();

        Thread.sleep(5000);

        //Thread.sleep(5000);
        chromeDriver.close();
        chromeDriver.quit();
    }
}
