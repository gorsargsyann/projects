package autotests.elements;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;

public class BasicButtonsTest {
    public static void main(String[] args) throws InterruptedException {

        WebDriverManager.chromedriver().setup();
        ChromeDriver chromeDriver = new ChromeDriver();
        Actions action = new Actions(chromeDriver);

        JavascriptExecutor executor = (JavascriptExecutor) chromeDriver;
        PageFactory.initElements(chromeDriver, new BasicRadioButtonTest());

        chromeDriver.get("https://demoqa.com/");
        chromeDriver.manage().window().maximize();

        Thread.sleep(2000);
        chromeDriver.findElementByXPath("//*[text() = 'Elements']").click();

        Thread.sleep(3000);
        Assert.assertTrue(chromeDriver
                .findElementByXPath("//*[text() = 'Please select an item from left to start practice.']")
                .isDisplayed());

        Thread.sleep(2000);
        Assert.assertTrue(chromeDriver.getCurrentUrl().endsWith("elements"));

        chromeDriver.findElementByXPath("//span[text() = 'Buttons']").click();
        executor.executeScript("window.scrollBy(0, 150)","");

        //Double
        WebElement doubleClickBtn = chromeDriver.findElementById("doubleClickBtn");
        action.doubleClick(doubleClickBtn).perform();
        Assert.assertTrue(chromeDriver.findElementById("doubleClickMessage").isDisplayed());

        //Right
        WebElement rightClickBtn = chromeDriver.findElementById("rightClickBtn");
        action.contextClick(rightClickBtn).perform();
        Assert.assertTrue(chromeDriver.findElementById("rightClickMessage").isDisplayed());

        //Click
        WebElement click = chromeDriver.findElementByXPath("//*[text() = 'Click Me']");
        click.click();
        Assert.assertTrue(chromeDriver.findElementByXPath("//*[text() = 'You have done a dynamic click']").isDisplayed());

        Thread.sleep(3000);

        chromeDriver.close();
        chromeDriver.quit();
    }
}
