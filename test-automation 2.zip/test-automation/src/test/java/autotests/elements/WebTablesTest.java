//package autotests.elements;
//
//import autotests.BaseTest;
//import framework.pages.elements.WebTablesPage;
//import org.testng.Assert;
//import org.testng.annotations.Test;
//
//public class WebTablesTest extends BaseTest {
//
//    @Test
//    public void webTablesTest() throws InterruptedException {
//        webTablesPage.clickOnElementsSection();
//        webTablesPage.clickOnWebTablesSection();
//
//        Assert.assertTrue(driver().getCurrentUrl().endsWith(webTablesPage.getWebTablesPagePath()));
//        scrollTo();
//
//        webTablesPage.ClickOnAddNewRecordButton();
//        webTablesPage.firstNameInput();
//        webTablesPage.lastNameInput();
//        webTablesPage.emailInput();
//        webTablesPage.ageInput();
//        webTablesPage.salaryInput();
//        webTablesPage.departmentInput();
//        webTablesPage.clickOnSubmitButton();
//
//        Assert.assertTrue(webTablesPage.isEmailDisplayed());
//
//        webTablesPage.clickOnEditButton();
//        webTablesPage.newEmailAddress();
//
//        webTablesPage.clickOnSubmitButton();
//
//        webTablesPage.clickOnDeleteButton();
//    }
//
//}
