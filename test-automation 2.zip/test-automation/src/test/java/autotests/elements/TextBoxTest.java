package autotests.elements;

import autotests.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TextBoxTest extends BaseTest {

    @Test
    public void textBoxTest() throws InterruptedException {
        scrollTo();
        textBoxPage.clickOnElementsSection();
        textBoxPage.clickOnTextBoxSection();

        Assert.assertTrue(driver().getCurrentUrl().endsWith(textBoxPage.getTextBoxPagePath()));

        scrollTo();

        textBoxPage.inputFullName();
        textBoxPage.inputEmail();
        textBoxPage.inputCurrentAddress();
        textBoxPage.inputPermanentAddress();
        textBoxPage.clickSubmit();

        Assert.assertTrue(textBoxPage.isOutputDisplayed());

    }
}
