package autotests.elements;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class BasicRadioButtonTest {
    public static void main(String[] args) throws InterruptedException {

        WebDriverManager.chromedriver().setup();
        ChromeDriver chromeDriver = new ChromeDriver();

        JavascriptExecutor executor = (JavascriptExecutor) chromeDriver;
        PageFactory.initElements(chromeDriver, new BasicRadioButtonTest());

        chromeDriver.get("https://demoqa.com/");
        chromeDriver.manage().window().maximize();

        Thread.sleep(2000);
        chromeDriver.findElementByXPath("//*[text() = 'Elements']").click();

        Thread.sleep(3000);
        Assert.assertTrue(chromeDriver
                .findElementByXPath("//*[text() = 'Please select an item from left to start practice.']")
                .isDisplayed());

        Thread.sleep(2000);
        Assert.assertTrue(chromeDriver.getCurrentUrl().endsWith("elements"));

        chromeDriver.findElementByXPath("//span[text() = 'Radio Button']").click();
        Assert.assertTrue(chromeDriver.getCurrentUrl().endsWith("radio-button"));
        Thread.sleep(3000);

        //Yes
        chromeDriver.findElementByXPath("//*[@for = 'yesRadio']").click();
        Assert.assertTrue(chromeDriver.findElementByXPath("//span[text() = 'Yes']").isDisplayed());
        Thread.sleep(2000);

        //Impressive
        chromeDriver.findElementByXPath("//*[@for = 'impressiveRadio']").click();
        Assert.assertTrue(chromeDriver.findElementByXPath("//span[text() = 'Impressive']").isDisplayed());
        Thread.sleep(2000);

        //No
        chromeDriver.findElementByXPath("//*[@for = 'noRadio']").click();
        chromeDriver.findElementByXPath("//*[@for = 'noRadio']").getText().equals("Impressive");
        Assert.assertTrue(chromeDriver.findElementByXPath("//span[text() = 'Impressive']").isDisplayed());

        Thread.sleep(3000);

        chromeDriver.close();
        chromeDriver.quit();

    }
}
