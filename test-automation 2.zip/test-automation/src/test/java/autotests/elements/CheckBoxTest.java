package autotests.elements;

import autotests.BaseTest;
import org.openqa.selenium.NoSuchElementException;
import org.testng.annotations.Test;
import org.testng.Assert;

public class CheckBoxTest extends BaseTest {

    @Test
    public void checkBoxTest() throws InterruptedException {
        scrollTo();
        checkBoxPage.clickOnElementsSection();
        checkBoxPage.clickOnCheckBoxButtonBtn();

        Assert.assertTrue(driver().getCurrentUrl().endsWith(checkBoxPage.getCheckBoxPagePath()));
        scrollTo();

        checkBoxPage.clickOnPlusButton();
        scrollTo();
        checkBoxPage.clickOnNotesButton();
        checkBoxPage.clickOnReactButton();
        checkBoxPage.clickOnOfficeButton();
        checkBoxPage.clickOnWordFileButton();

        checkBoxPage.clickOnCloseOfficeWindowButton();

        try {
            Assert.assertFalse(checkBoxPage.isOfficeFieldsDisplayed());
        }catch (NoSuchElementException e) {
            System.out.println("After Closing");
        }finally {
            System.out.println("Office Field Is Not Displayed");
        }

        checkBoxPage.clickOnMinusButton();

        checkBoxPage.isYouHaveSelectedTextDisplayed();
    }
}
