package autotests.elements;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class BasicCheckBoxTest {
    public static void main(String[] args) throws InterruptedException {


        WebDriverManager.chromedriver().setup();
        ChromeDriver chromeDriver = new ChromeDriver();

        JavascriptExecutor executor = (JavascriptExecutor) chromeDriver;
        PageFactory.initElements(chromeDriver, new BasicTest());

        chromeDriver.get("https://demoqa.com/");
        chromeDriver.manage().window().maximize();


        Thread.sleep(2000);
        //executor.executeScript("window.scrollBy(0,350)", "");
        chromeDriver.findElementByXPath("//*[text() = 'Elements']").click();

        Thread.sleep(3000);
        Assert.assertTrue(chromeDriver
                .findElementByXPath("//*[text() = 'Please select an item from left to start practice.']")
                .isDisplayed());

        Thread.sleep(3000);
        Assert.assertTrue(chromeDriver.getCurrentUrl().endsWith("elements"));

        chromeDriver.findElementByXPath("//span[text() = 'Check Box']").click();

        WebElement plus = chromeDriver.findElementByXPath("//*[@class = 'rct-icon rct-icon-expand-all']");
        WebElement minus = chromeDriver.findElementByXPath("//*[@class = 'rct-option rct-option-collapse-all']");

        Thread.sleep(3000);
        plus.click();
        executor.executeScript("window.scrollBy(0, 300)","");
        chromeDriver.findElementByCssSelector("[for = 'tree-node-notes'").click();
        chromeDriver.findElementByCssSelector("[for = 'tree-node-react'").click();
        chromeDriver.findElementByCssSelector("[for = 'tree-node-office'").click();
        chromeDriver.findElementByCssSelector("[for = 'tree-node-wordFile'").click();

        chromeDriver.findElementByCssSelector("#tree-node > ol > li > ol > li:nth-child(2) > ol > li:nth-child(2) > span > button > svg")
                        .click();

        Assert.assertTrue(chromeDriver.findElementById("result").isDisplayed());
//        Assert.assertFalse(chromeDriver.findElementByCssSelector("[for = 'tree-node-private'").isDisplayed());

        minus.click();

        Thread.sleep(7000);

        chromeDriver.findElementById("result").getText();

        chromeDriver.close();
        chromeDriver.quit();

    }
}
