package autotests.elements;

import autotests.BaseTest;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ButtonsTest extends BaseTest {

    @Test
    public void ButtonsTest() throws InterruptedException {

        buttonsPage.clickOnElementsSection();
        buttonsPage.clickOnButtonsBtn();

        Assert.assertTrue(driver().getCurrentUrl().endsWith(buttonsPage.getButtonsPagePath()));

        buttonsPage.clickOnDoubleClickBtn();
        Assert.assertTrue(buttonsPage.isDoubleClickMessageDisplayed());

        buttonsPage.ClickOnRightClickBtn();
        Assert.assertTrue(buttonsPage.isRightClickMessageDisplayed());

        buttonsPage.clickOnClickButton();
        Assert.assertTrue(buttonsPage.isClickMessageDisplayed());
    }
}
