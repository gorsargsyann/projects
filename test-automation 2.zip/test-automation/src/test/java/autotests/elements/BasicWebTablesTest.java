package autotests.elements;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

    public class BasicWebTablesTest {
        public static void main(String[] args) throws InterruptedException {

            WebDriverManager.chromedriver().setup();
            ChromeDriver chromeDriver = new ChromeDriver();

            JavascriptExecutor executor = (JavascriptExecutor) chromeDriver;
            PageFactory.initElements(chromeDriver, new autotests.elements.BasicTest());

            chromeDriver.get("https://demoqa.com/");
            chromeDriver.manage().window().maximize();


            Thread.sleep(10000);
            //executor.executeScript("window.scrollBy(0,350)", "");
            chromeDriver.findElementByXPath("//*[text() = 'Elements']").click();

            Thread.sleep(20000);
            Assert.assertTrue(chromeDriver
                    .findElementByXPath("//*[text() = 'Please select an item from left to start practice.']")
                    .isDisplayed());

            Thread.sleep(5000);
            Assert.assertTrue(chromeDriver.getCurrentUrl().endsWith("elements"));

            //chromeDriver.findElementByXPath("//*[text() = 'Text Box']").click();


            chromeDriver.findElementByXPath("//*[text() = 'Web Tables']").click();
            Thread.sleep(2000);
            chromeDriver.findElementById("addNewRecordButton").click();
            WebElement firstNameInput = chromeDriver.findElementById("firstName");
            WebElement lastNameInput = chromeDriver.findElementById("lastName");
            WebElement emailInput = chromeDriver.findElementById("userEmail");
            WebElement ageInput = chromeDriver.findElementById("age");
            WebElement salaryInput = chromeDriver.findElementById("salary");
            WebElement departmentInput = chromeDriver.findElementById("department");
            WebElement submitButton = chromeDriver.findElementById("submit");

            firstNameInput.sendKeys("Name");
            lastNameInput.sendKeys("Last");
            emailInput.sendKeys("test@gmail.com");
            ageInput.sendKeys("22");
            salaryInput.sendKeys("1230000");
            departmentInput.sendKeys("Mobile Development");
            submitButton.click();
            Thread.sleep(2000);

            Assert.assertTrue(chromeDriver.findElementByXPath("//*[text() = 'test@gmail.com']").isDisplayed());

            //EDIT
            chromeDriver.findElementByCssSelector("#edit-record-4 > svg > path").click();
//            emailInput.sendKeys(Keys.CONTROL + "a", Keys.DELETE);
            emailInput.sendKeys(Keys.BACK_SPACE);
            emailInput.sendKeys("newmail@gmail.com");
            submitButton.click();

            //DELETE
            chromeDriver.findElementByCssSelector("#delete-record-4 > svg > path").click();



            Thread.sleep(5000);


            chromeDriver.close();
            chromeDriver.quit();
        }
    }

