package autotests.elements;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class BasicTest {
    public static void main(String[] args) throws InterruptedException {

        WebDriverManager.chromedriver().setup();
        ChromeDriver chromeDriver = new ChromeDriver();

        JavascriptExecutor executor = (JavascriptExecutor) chromeDriver;
        PageFactory.initElements(chromeDriver, new BasicTest());

        chromeDriver.get("https://demoqa.com/");
        chromeDriver.manage().window().maximize();


        Thread.sleep(2000);
        //executor.executeScript("window.scrollBy(0,350)", "");
        chromeDriver.findElementByXPath("//*[text() = 'Elements']").click();

        Thread.sleep(3000);
        Assert.assertTrue(chromeDriver
                .findElementByXPath("//*[text() = 'Please select an item from left to start practice.']")
                .isDisplayed());

        Thread.sleep(3000);
        Assert.assertTrue(chromeDriver.getCurrentUrl().endsWith("elements"));

        chromeDriver.findElementByXPath("//*[text() = 'Text Box']").click();

        WebElement fullNameInput = chromeDriver.findElementById("userName");
        WebElement emailInput = chromeDriver.findElement(By.cssSelector("[type='email']"));
        WebElement currentAddressInput = chromeDriver.findElementById("currentAddress");
        WebElement permanentAddressInput = chromeDriver.findElementById("permanentAddress");
        WebElement submitButton = chromeDriver.findElementById("submit");

        Assert.assertTrue(fullNameInput.isDisplayed());
        Assert.assertTrue(emailInput.isDisplayed());
        Assert.assertTrue(currentAddressInput.isDisplayed());
        Assert.assertTrue(permanentAddressInput.isDisplayed());
        Assert.assertTrue(submitButton.isDisplayed());



        fullNameInput.sendKeys("John");
        emailInput.sendKeys("test@gmail.com");
        currentAddressInput.sendKeys("ddssaa");
        permanentAddressInput.sendKeys("Perm Address");


        executor.executeScript("window.scrollBy(0, 250)", "");
        submitButton.click();

        executor.executeScript("window.scrollBy(0, 100)", "");

        Assert.assertTrue(chromeDriver.findElementByCssSelector("#output #email")
                .getText()
                .endsWith("test@gmail.com"));

        Assert.assertTrue(chromeDriver.findElementByCssSelector("#output #name")
                        .getText()
                        .endsWith("John"));


        Assert.assertTrue(chromeDriver.findElementByCssSelector("#output #currentAddress")
                .getText()
                .endsWith("ddssaa"));


        Assert.assertTrue(chromeDriver.findElementByCssSelector("#output #permanentAddress")
                .getText()
                .endsWith("Perm Address"));

        chromeDriver.findElementByCssSelector("[id = submit").click();

        Thread.sleep(5000);

        chromeDriver.close();
        chromeDriver.quit();
    }
}
