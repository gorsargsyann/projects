package autotests.elements;

import autotests.BaseTest;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.Assert;

public class RadioButtonsTest extends BaseTest{

    @BeforeMethod
    public void openRadioButtonPage() throws InterruptedException {
        scrollTo();
        radioButtonsPage.clickOnElementsSection();
        radioButtonsPage.clickOnRadioButtonBtn();

        Assert.assertTrue(driver().getCurrentUrl().endsWith(radioButtonsPage.getRadioButtonPagePath()));

        scrollTo();
    }

    @Test(priority = 1)
    public void checkYesRadioButtonFunctionality() throws InterruptedException {
        radioButtonsPage.clickOnYesRadioButton();

        Assert.assertTrue(radioButtonsPage.isYouHaveSelectedMessageDisplayed());
        Assert.assertTrue(radioButtonsPage.isYesHaveMessageDisplayed());
    }

    @Test(priority = 2)
    public void checkImpressiveRadioButtonFunctionality() throws InterruptedException {
        radioButtonsPage.clickOnImpressiveRadioButton();

        Assert.assertTrue(radioButtonsPage.isYouHaveSelectedMessageDisplayed());
        Assert.assertTrue(radioButtonsPage.isImpressiveMessageDisplayed());
    }

    @Test(priority = 3)
    public void checkNoRadioButtonDisabled() throws InterruptedException {
        radioButtonsPage.clickOnYesRadioButton();
        Assert.assertFalse(radioButtonsPage.isNoRadioButtonEnable());
    }

}
