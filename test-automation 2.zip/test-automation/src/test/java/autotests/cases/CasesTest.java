package autotests.cases;

import autotests.BaseTest;
import framework.helpers.WaitHelper;
import org.openqa.selenium.NoSuchElementException;
import org.testng.Assert;
import org.testng.annotations.Test;

public class CasesTest extends BaseTest {

    @Test(invocationCount = 2)
    public void casesTest() throws InterruptedException {
        String singleColorNameRed = "Red";
        String multipleColorNamesRed = "Red";
        String multipleColorNamesBlue = "Blue";

        cases.clickOnElementsSection();
        cases.clickOnWebTablesBtn();
        scrollTo();

        Assert.assertTrue(cases.isCierraTextDisplayed());
        try {
            Assert.assertFalse(cases.isAlexTextDisplayed());
        }catch (NoSuchElementException e) {
            System.out.println("No rows found");
        }

        openHomePage();

        cases.clickOnWidgetsSection();
        cases.clickOnAutoCompleteBtn();
        cases.setSingleColorNameInputRed(singleColorNameRed);
        cases.selectRedForSingle();

        cases.setMultipleColorNamesInputRed(multipleColorNamesRed);
        cases.selectRedForMultiple();
        cases.setMultipleColorNamesInputBlue(multipleColorNamesBlue);
        cases.selectBlueForMultiple();
        scrollTo();

        cases.clickOnTabsBtn();

        cases.clickOnWhatTab();
        cases.lengthOfWhatTab();
        cases.clickOnOriginTab();
        cases.lengthOfOriginTab();
        cases.clickOnUseTab();
        cases.lengthOfUseTab();
        if (cases.lengthOfWhatTab() != cases.lengthOfOriginTab() && cases.lengthOfWhatTab() != cases.lengthOfUseTab()
        && cases.lengthOfOriginTab() != cases.lengthOfUseTab()){
            System.out.println("Texts different with length");
        }else {
            System.out.println("Texts NOT different with length");
        }
        try {
            Assert.assertFalse(cases.isMoreTabEnable());
        }catch (AssertionError e) {
            System.out.println("More Is Not Enable");
        }
    }
}
