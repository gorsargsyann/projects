package autotests.demo;

import autotests.BaseTest;
import framework.helpers.CommonHelper;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ActionsDemo extends BaseTest {

    @Test
    public void demoActions() throws InterruptedException {
        Actions action = new Actions(driver());


//55555555
//        textBoxPage.clickOnElementsSection();
//        driver().findElementByXPath("//*[text() = 'Upload and Download']").click();
//
//        Thread.sleep(3000);
//        WebElement uploadImage = driver().findElementById("uploadFile");
//        uploadImage.sendKeys("/Users/gorsargsyan/Desktop/test-automation/src/test/resources/7960611f-9837-452e-9c9e-3ba3c9fb01e4.png");
//
//        Thread.sleep(5000);


//444444444
//        textBoxPage.clickOnElementsSection();
//
//        action.moveToElement(driver().findElementById("//*[text() = 'Interactions']")).perform();
//        Thread.sleep(10000);
//
//
//        WebElement interaction = driver().findElementById("//*[text() = 'Interactions']");
//        CommonHelper.moveToElement(action, interaction);


//333333333
//        textBoxPage.clickOnElementsSection();
//        textBoxPage.clickOnTextBoxSection();
//
//        checkFullName(action, "ashot", "azganun");
//
//        System.out.println();
//
//
//    }
//
//    private void checkFullName(Actions action, String name, String last) {
//        if(name.equals(name.toLowerCase()) && last.equals(last.toLowerCase())){
//            action
//                    .keyDown(driver().findElementById("userName"), Keys.SHIFT)
//                    .sendKeys(driver().findElementById("userName"), name + " " + last)
//                    .perform();
//        }

//222222222
//        textBoxPage.clickOnInteractionsSection();
//
//
//        JavascriptExecutor ex = (JavascriptExecutor) driver();
//        ex.executeScript("window.scrollBy(0, 300)");
//
//        driver().findElementByXPath("//*[text() = 'Droppable']").click();
//
//        WebElement fromElement = driver().findElementById("draggable");
//        WebElement toElement = driver().findElementById("droppable");
//
//        String classAtr = toElement.getAttribute("class");
//
//        Assert.assertEquals(classAtr, "drop-box ui-droppable");
//
//        Thread.sleep(3000);
//
//        action
//                .dragAndDrop(fromElement, toElement)
//                .perform();
//
//        classAtr = toElement.getAttribute("class");
//
//        Assert.assertEquals(classAtr, "drop-box ui-droppable ui-state-highlight");


//111111111
//        driver().findElementByXPath("//*[text() = 'Elements']").click();
//        driver().findElementByXPath("//span[text() = 'Buttons']").click();
//        WebElement doubleClickBtn = driver().findElementById("doubleClickBtn");
//        action.doubleClick(doubleClickBtn).perform();
//        WebElement dbcMessage = driver().findElementById("doubleClickMessage");
//        Assert.assertEquals(dbcMessage, "You have done a double click");

    }
}
