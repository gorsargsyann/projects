package framework.pages.forms;

import framework.helpers.WaitHelper;
import framework.pages.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;

public class FormsPage extends BasePage {
    private final String PATH = "/automation-practice-form";

    private WaitHelper waitHelper;

    @FindBy(xpath = "//*[text() = 'Practice Form']")
    private WebElement pracFormSection;

    @FindBy(id = "firstName")
    private WebElement fName;

    @FindBy(id = "lastName")
    private WebElement lName;

    @FindBy(id = "userEmail")
    private WebElement email;

    @FindBy(css = "[for='gender-radio-1']")
    private WebElement genderMale;

    @FindBy(id = "userNumber")
    private WebElement phoneNumber;

    @FindBy(id = "dateOfBirthInput")
    private WebElement dateBirth;

    @FindBy(id = "subjectsInput")
    private WebElement subjects;

    @FindBy(css = "[for='hobbies-checkbox-2']")
    private WebElement hobbiesReading;

    @FindBy(id = "currentAddress")
    private WebElement currentAddress;

    @FindBy(id = "submit")
    private WebElement submitButton;

    public FormsPage(ChromeDriver driver) {
        super(driver);
        waitHelper = new WaitHelper(driver);
    }

    public void pracFormSection() {
        pracFormSection.click();
    }
    public void setfName(String fNameInput) {
        fName.sendKeys(fNameInput);
    }

    public void setlName(String lNameInput) {
        lName.sendKeys(lNameInput);
    }

    public void setEmail(String emailInput) {
        email.sendKeys(emailInput);
    }

    public void setPhoneNumber(String phoneNumberInput) {
        waitHelper.waitUntilVisibility(phoneNumber, 12);
        phoneNumber.sendKeys(phoneNumberInput);
    }

    public void setCurrentAddress(String currentAddressInput) {
        currentAddress.sendKeys(currentAddressInput);
    }

    public void selectGenderMale(){
        genderMale.click();
    }

    public void clickOnSubmit(){
        waitHelper.waitUntilVisibility(submitButton);
        submitButton.click();
    }
}