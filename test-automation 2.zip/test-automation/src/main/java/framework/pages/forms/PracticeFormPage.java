package framework.pages.forms;

import framework.pages.BasePage;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import framework.helpers.WaitHelper;

import java.util.List;

public class PracticeFormPage extends BasePage {

    private final String PATH = "practice-form";

    private WaitHelper waitHelper;
    @FindBy(xpath = "//*[text() = 'Practice Form']"
    )
    private WebElement practiceFormPageButtonBtn;

    @FindBy(id = "firstName")
    private WebElement firstNameInput;

    @FindBy(id = "lastName")
    private WebElement lastNameInput;

    @FindBy(id = "userEmail")
    private WebElement emailInput;

    @FindBy(css = "[for = 'gender-radio-1'")
    private WebElement maleInput;

    @FindBy(css = "[for = 'gender-radio-2'")
    private WebElement femaleInput;

    @FindBy(css = "[for = 'gender-radio-3'")
    private WebElement otherInput;

    @FindBy(id = "userNumber")
    private WebElement mobileInput;

    @FindBy(id = "dateOfBirthInput")
    private WebElement dateOfBirthInput;

    @FindBy(id = "subjectsInput")
    private WebElement subjectsInput;

    @FindBy(css = "#hobbiesWrapper > div.col-md-9.col-sm-12 > div:nth-child(1) > label")
    private WebElement sportsInput;

    @FindBy(css = "#hobbiesWrapper > div.col-md-9.col-sm-12 > div:nth-child(2) > label")
    private WebElement readingInput;

    @FindBy(css = "#hobbiesWrapper > div.col-md-9.col-sm-12 > div:nth-child(3) > label")
    private WebElement musicInput;

    @FindBy(id = "uploadPicture")
    private WebElement pictureInput;

    @FindBy(id = "currentAddress")
    private WebElement currentAddressInput;

    @FindBy(id = "submit")
    private WebElement submitButton;

    @FindBy(css = ".react-datepicker__month-select")
    private WebElement monthSelect;

    @FindBy(css = ".react-datepicker__year-select")
    private WebElement yearSelect;

    @FindBy(css = ".react-datepicker__day")
    private List<WebElement> day;

    @FindBy(xpath = "//*[text() = 'Select State']")
    private WebElement selectState;

    @FindBy(xpath = "//*[text() = 'NCR']")
    private WebElement selectNCR;

    @FindBy(xpath = "//*[text() = 'Select City']")
    private WebElement selectCity;

    @FindBy(xpath = "//*[text() = 'Gurgaon']")
    private WebElement selectGurgaon;

    public PracticeFormPage(ChromeDriver driver) {
        super(driver);
    }

    public void clickOnPracticeFormSection() throws InterruptedException {
        System.out.println("Click On Practice Form Section");
        practiceFormPageButtonBtn.click();
        WaitHelper.pause(5);
    }

    public String getPracticeFormPagePath() {
        return PATH;
    }

    public void inputFirstName() {
        firstNameInput.sendKeys("Gor");
    }

    public void inputLastName() {
        lastNameInput.sendKeys("Sargsyan");
    }

    public void inputEmail() {
        emailInput.sendKeys("test@gmail.com");
    }

    public void selectGender() {
        maleInput.click();
    }

    public void inputMobile() {
        mobileInput.sendKeys("123321321123");
    }

    public void clickOnDateOfBirthBtn() {
        dateOfBirthInput.click();
    }

    public void selectYear() {
        new Select(yearSelect).selectByValue("1990");
    }

    public void selectMonth() {
        new Select(monthSelect).selectByVisibleText("June");
    }

    public void selectDay() {
        day.get(3).click();
    }

    public void inputSubjects() {
        subjectsInput.sendKeys("Eng");
        subjectsInput.sendKeys(Keys.ENTER);
    }

    public void selectHobbies() {
        sportsInput.click();
        musicInput.click();
    }

    public void inputPicture() {
        pictureInput.sendKeys("/Users/gorsargsyan/Downloads/7960611f-9837-452e-9c9e-3ba3c9fb01e4.png");
    }

    public void inputCurrentAddress() {
        currentAddressInput.sendKeys("Broadway 36");
    }

    public void selectState() {
        selectState.click();
    }

    public void selectNCR() {
        selectNCR.click();
    }

    public void selectCity() {
        selectCity.click();
    }

    public void selectGurgaon() {
        selectGurgaon.click();
    }

    public void clickSubmitBtn()  {
        waitHelper.waitUntilClickable(submitButton);
        submitButton.click();
    }
}
