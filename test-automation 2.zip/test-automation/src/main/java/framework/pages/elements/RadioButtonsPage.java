package framework.pages.elements;

import framework.helpers.WaitHelper;
import framework.pages.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;

public class RadioButtonsPage extends BasePage{

    private final String PATH = "/radio-button";

    @FindBy(xpath = "//span[text() = 'Radio Button']")
    private WebElement radioButtonBtn;

    @FindBy(css = "[for='yesRadio'")
    private WebElement yesRadioButton;

    @FindBy(css = "[for='impressiveRadio'")
    private WebElement impressiveRadioButton;

    @FindBy(id = "noRadio")
    private WebElement noRadioButton;

    @FindBy(xpath = "//*[contains(text(), 'You have selected ')]")
    private WebElement youHaveSelectedMessage;

    @FindBy(css = ".text-success")
    private WebElement successMessage;

    public RadioButtonsPage(ChromeDriver driver) {
        super(driver);
    }

    public void clickOnRadioButtonBtn() throws InterruptedException {
        radioButtonBtn.click();
        WaitHelper.pause(6);
    }

    public void clickOnYesRadioButton() {
        yesRadioButton.click();
    }

    public void clickOnImpressiveRadioButton() {
        impressiveRadioButton.click();
    }

    public String getRadioButtonPagePath() {
        return PATH;
    }

    public boolean isNoRadioButtonEnable() {
        return noRadioButton.isEnabled();
    }

    public boolean isYouHaveSelectedMessageDisplayed() {
        return youHaveSelectedMessage.isDisplayed();
    }

    public boolean isYesHaveMessageDisplayed() throws InterruptedException {
        WaitHelper.pause(4);
        return successMessage.isDisplayed();
    }

    public boolean isImpressiveMessageDisplayed() throws InterruptedException {
        WaitHelper.pause(4);
        return successMessage.isDisplayed();
    }
}
