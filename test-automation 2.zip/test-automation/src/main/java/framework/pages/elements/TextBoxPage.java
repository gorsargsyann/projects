package framework.pages.elements;

import framework.helpers.WaitHelper;
import framework.pages.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;

public class TextBoxPage extends BasePage {

    private final String PATH = "/text-box";

    @FindBy(xpath = "//*[text()='Text Box']")
    private WebElement textBoxButtonBtn;

    @FindBy(id = "userName")
    private WebElement fullNameInput;

    @FindBy(id = "userEmail")
    private WebElement email;

    @FindBy(id = "currentAddress")
    private WebElement currentAddress;

    @FindBy(id = "permanentAddress")
    private WebElement permanentAddress;

    @FindBy(id = "submit")
    private WebElement submit;

    @FindBy(id = "output")
    private WebElement output;

    public TextBoxPage(ChromeDriver driver) {
        super(driver);
    }

    public void clickOnTextBoxSection() throws InterruptedException {
        System.out.println("Click on text box section");
        textBoxButtonBtn.click();
        WaitHelper.pause(5);
    }

    public String getTextBoxPagePath() {
        return PATH;
    }

    public boolean isFullNameInputDisplayed() {
        System.out.println("Check full name input field displayed");
        return fullNameInput.isDisplayed();
    }


    public void inputFullName() {
        fullNameInput.sendKeys("Name Lastname");
    }

    public void inputEmail() {
        email.sendKeys("test@gmail.com");
    }

    public void inputCurrentAddress() {
        currentAddress.sendKeys("Broadway");
    }

    public void inputPermanentAddress() {
        permanentAddress.sendKeys("42");
    }

    public void clickSubmit() throws InterruptedException {
        submit.click();
        WaitHelper.pause(3);
    }

    public boolean isOutputDisplayed() throws InterruptedException {
        WaitHelper.pause(3);
        return output.isDisplayed();
    }
}
