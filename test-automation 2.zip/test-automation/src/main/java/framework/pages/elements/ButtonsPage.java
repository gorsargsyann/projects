package framework.pages.elements;

import framework.pages.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import framework.helpers.WaitHelper;

public class ButtonsPage extends BasePage {

    private final String PATH = "/buttons";

//    Actions actions = new Actions(new ChromeDriver());

    @FindBy(xpath = "//span[text() = 'Buttons']")
    private WebElement buttonsButtonBtn;

    @FindBy(id = "doubleClickBtn")
    private WebElement doubleClickBtn;

    @FindBy(id = "doubleClickMessage")
    private WebElement doubleClickMessage;

    @FindBy(id = "rightClickBtn")
    private WebElement rightClickBtn;

    @FindBy(id = "rightClickMessage")
    private WebElement rightClickMessage;

    @FindBy(xpath = "//*[text() = 'Click Me']")
    private WebElement clickButton;

    @FindBy(xpath = "//*[text() = 'You have done a dynamic click']")
    private WebElement clickMessage;


    public ButtonsPage(ChromeDriver driver) {
        super(driver);
    }

    public void clickOnButtonsBtn() throws InterruptedException {
        buttonsButtonBtn.click();
        WaitHelper.pause(4);
    }

    public String getButtonsPagePath() {
        return PATH;
    }

    public void clickOnDoubleClickBtn() {
//        actions.doubleClick(doubleClickBtn).build().perform();
    }

    public boolean isDoubleClickMessageDisplayed() {
        return doubleClickMessage.isDisplayed();
    }

    public void ClickOnRightClickBtn() {
//        actions.contextClick(rightClickBtn).build().perform();
    }

    public boolean isRightClickMessageDisplayed() {
        return rightClickMessage.isDisplayed();
    }

    public void clickOnClickButton() {
        clickButton.click();
    }

    public boolean isClickMessageDisplayed() throws InterruptedException {
        WaitHelper.pause(5);
        return clickMessage.isDisplayed();
    }
}
