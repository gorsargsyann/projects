package framework.pages.elements;

import framework.helpers.WaitHelper;
import framework.pages.BasePage;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;

public class WebTablesPage extends BasePage {

    private final String PATH = "/webtables";


    @FindBy(xpath = "//*[text() = 'Web Tables']")
    private WebElement webTablesButtonBtn;

    @FindBy(id = "addNewRecordButton")
    private WebElement addNewRecordButton;

    @FindBy(id = "firstName")
    private WebElement firstNameInput;

    @FindBy(id = "lastName")
    private WebElement lastNameInput;

    @FindBy(id = "userEmail")
    private WebElement emailInput;

    @FindBy(id = "age")
    private WebElement ageInput;

    @FindBy(id = "salary")
    private WebElement salaryInput;

    @FindBy(id = "department")
    private WebElement departmentInput;

    @FindBy(id = "submit")
    private WebElement submitButtonClick;

//    @FindBy(xpath = "//*[text() = 'test@gmail.com']")
//    private WebElement isEmailDisplayed;

    @FindBy(css = "#edit-record-4 > svg > path")
    private WebElement editButton;

    @FindBy(css = "#delete-record-4 > svg > path")
    private WebElement deleteButton;


    public WebTablesPage(ChromeDriver driver) {
        super(driver);
    }

    public void clickOnWebTablesSection() {
        waitHelper.waitUntilVisibility(webTablesButtonBtn);
        webTablesButtonBtn.click();
    }

    public String getWebTablesPagePath() {
        return PATH;
    }

    public void ClickOnAddNewRecordButton() {
        waitHelper.waitUntilVisibility(addNewRecordButton);
        waitHelper.waitUntilClickable(addNewRecordButton);
        addNewRecordButton.click();
        waitHelper.waitUntilVisibility(firstNameInput);
        waitHelper.waitUntilVisibility(ageInput);
    }

    public void setFirstNameInput(String firstName) {
        firstNameInput.sendKeys(firstName);
    }

    public void setLastNameInput(String lastName) {
        lastNameInput.sendKeys(lastName);
    }

    public void setEmailInput(String email) {
        emailInput.sendKeys(email);
    }

    public void setAgeInput(String age) {
        ageInput.sendKeys(age);
    }

    public void setSalaryInput(String salary) {
        salaryInput.sendKeys(salary);
    }

    public void setDepartmentInput(String department) {
        departmentInput.sendKeys(department);
    }

    public void clickOnSubmitButton() {
        waitHelper.waitUntilClickable(submitButtonClick);
        submitButtonClick.click();
    }

//    public boolean isEmailDisplayed() {
//        return isEmailDisplayed.isDisplayed();
//    }

    public void clickOnEditButton() {
        editButton.click();
    }

    public void newEmailAddress() {
//        actions.moveToElement(emailInput).keyDown(Keys.CONTROL).sendKeys("a", Keys.BACK_SPACE).keyUp(Keys.CONTROL).perform();
        emailInput.sendKeys(Keys.COMMAND, "a", Keys.BACK_SPACE);
        emailInput.sendKeys("new@gmail.com");
    }

    public void clickOnDeleteButton() throws InterruptedException {
        deleteButton.click();
        WaitHelper.pause(5);
    }

    public void userRegistration(String firstName, String lastName, String email, String age, String salary, String department) {
        ClickOnAddNewRecordButton();
        setFirstNameInput(firstName);
        setLastNameInput(lastName);
        setEmailInput(email);
        setAgeInput(age);
        setSalaryInput(salary);
        setDepartmentInput(department);
        clickOnSubmitButton();
    }
}
