package framework.pages.elements;

import framework.helpers.WaitHelper;
import framework.pages.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;

public class CheckBoxPage extends BasePage {
    private final String PATH = "/checkbox";

    public CheckBoxPage(ChromeDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//span[text() = 'Check Box']")
    private WebElement checkBoxButtonBtn;

    @FindBy(css = "[for = 'tree-node-notes'")
    private WebElement notesButton;

    @FindBy(css = "[for = 'tree-node-react'")
    private WebElement reactButton;

    @FindBy(css = "[for = 'tree-node-office'")
    private WebElement officeButton;

    @FindBy(css = "[for = 'tree-node-wordFile'")
    private WebElement wordFileButton;

    @FindBy(xpath = "//*[@class = 'rct-icon rct-icon-expand-all']")
    private WebElement plusButton;

    @FindBy(xpath = "//*[@class = 'rct-option rct-option-collapse-all']")
    private WebElement minusButton;

    @FindBy(css = "#tree-node > ol > li > ol > li:nth-child(2) > ol > li:nth-child(2) > span > button > svg")
    private WebElement closeOfficeWindowButton;

    @FindBy(xpath = "//*[contains(text(), 'You have selected')]")
    private WebElement youHaveSelectedText;

    @FindBy(css = "#tree-node > ol > li > ol > li:nth-child(2) > ol > li:nth-child(2) > ol")
    private WebElement officeFields;


    public String getCheckBoxPagePath() {
        return PATH;
    }

    public void clickOnCheckBoxButtonBtn() throws InterruptedException {
        checkBoxButtonBtn.click();
        WaitHelper.pause(5);
    }

    public void clickOnPlusButton() throws InterruptedException {
        plusButton.click();
        WaitHelper.pause(2);
    }

    public void clickOnNotesButton() {
        notesButton.click();
    }

    public void clickOnReactButton() {
        reactButton.click();
    }

    public void clickOnOfficeButton() {
        officeButton.click();
    }

    public void clickOnWordFileButton() {
        wordFileButton.click();
    }

    public void clickOnCloseOfficeWindowButton() {
        closeOfficeWindowButton.click();
    }

    public void clickOnMinusButton() {
        minusButton.click();
    }

    public boolean isYouHaveSelectedTextDisplayed() throws InterruptedException {
        WaitHelper.pause(3);
        return youHaveSelectedText.isDisplayed();
    }

    public boolean isOfficeFieldsDisplayed() {
        System.out.println("Before Closing");
        System.out.println("Office Field Is Displayed");
        return officeFields.isDisplayed();
    }
}
