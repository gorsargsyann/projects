package framework.pages;

import framework.helpers.WaitHelper;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class BasePage {

    public WaitHelper waitHelper;
    public BasePage(ChromeDriver driver) {
        PageFactory.initElements(driver, this);
        waitHelper = new WaitHelper(driver);
    }

    @FindBy(xpath = "//*[text()='Elements']")
    private WebElement elementsButton;

    @FindBy(xpath = "//*[text() = 'Forms']")
    private WebElement formsButton;

    @FindBy(xpath = "//*[text() = 'Widgets']")
    private WebElement widgetsButton;

    @FindBy(xpath = "//*[text() = 'Book Store Application']")
    private WebElement bookStoreApplicationButton;

    @FindBy(xpath = "//*[text() = 'Interactions']")
    private WebElement interactionsButton;

    public void clickOnElementsSection() {
        System.out.println("Click on elements section");
        elementsButton.click();
    }

    public void clickOnFormsSection(){
        System.out.println("Click on forms section");
        formsButton.click();
    }

    public void clickOnWidgetsSection(){
        System.out.println("Click on widgets section");
        widgetsButton.click();
    }

    public void clickOnInteractionsSection(){
        interactionsButton.click();
    }

    public void clickOnBookStoreApplicationSection() {
        bookStoreApplicationButton.click();
    }
}
