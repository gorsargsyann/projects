package framework.constants;

public class Message {

    public static final String NOT_LOGGED_IN_MESSAGE
            = "Currently you are not logged into the Book Store application, please visit the ";
}
