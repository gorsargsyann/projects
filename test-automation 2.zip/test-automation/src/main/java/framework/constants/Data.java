package framework.constants;

import org.apache.hc.core5.util.Asserts;

import java.util.Scanner;

public class Data {
    private final String BASE_URL = "https://demoqa.com/";

    public static final String WRONG_PASSWORD = "test";

    public String getBaseUrl() {
        return BASE_URL;
    }
}
