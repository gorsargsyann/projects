package framework.book_store_application;

import framework.pages.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;

public class BookStorePage extends BasePage {

    @FindBy(xpath = "//*[text() = 'Profile']")
    private WebElement profileButton;


    public BookStorePage(ChromeDriver driver) {
        super(driver);
    }

    public void clickOnProfileButton() {
        waitHelper.waitUntilVisibility(profileButton);
        profileButton.click();
    }
}
