package framework.book_store_application;

import framework.pages.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;

import static framework.constants.Message.NOT_LOGGED_IN_MESSAGE;

public class ProfilePage extends BasePage {

    @FindBy(id = "notLoggin-label")
    private WebElement notLoggInMessage;

    @FindBy(css = "[href = '/register']")
    private WebElement registerLink;
    public ProfilePage(ChromeDriver driver) {
        super(driver);
    }

    public ProfilePage verifyNotLoggedInMessage() {
        assert notLoggInMessage.getText().startsWith(NOT_LOGGED_IN_MESSAGE);
        return this;
    }

    public RegisterPage clickOnRegisterLink(ChromeDriver driver) {
        registerLink.click();
        return new RegisterPage(driver);
    }


}
