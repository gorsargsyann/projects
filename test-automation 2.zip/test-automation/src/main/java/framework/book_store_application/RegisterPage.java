package framework.book_store_application;

import framework.pages.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;

public class RegisterPage extends BasePage {

    @FindBy(id = "firstname")
    private WebElement firstnameInput;

    @FindBy(id = "lastname")
    private WebElement lastnameInput;

    @FindBy(id = "userName")
    private WebElement userNameInput;

    @FindBy(id = "password")
    private WebElement passwordInput;

    @FindBy(id = "register")
    private WebElement registerButton;

    @FindBy(id = "gotologin")
    private WebElement goToLoginButton;

    @FindBy(id = "recaptcha-anchor-label")
    private WebElement captchaButton;

    @FindBy(css = "[title = 'reCAPTCHA']")
    private WebElement frame;


    public RegisterPage(ChromeDriver driver) {
        super(driver);
    }

    public RegisterPage verifyAllUIElements() {
    waitHelper.waitUntilVisibility(firstnameInput, 30);
    waitHelper.waitUntilVisibility(lastnameInput);
    waitHelper.waitUntilVisibility(userNameInput);
    waitHelper.waitUntilVisibility(passwordInput);
    waitHelper.waitUntilVisibility(passwordInput);
    waitHelper.waitUntilVisibility(goToLoginButton);
    return this;
    }

    public RegisterPage fillAllFields(String firstname, String lastname, String userName, String password) {
        firstnameInput.sendKeys(firstname);
        lastnameInput.sendKeys(lastname);
        userNameInput.sendKeys(userName);
        passwordInput.sendKeys(password);
        return this;
    }

    public RegisterPage tryAcceptCaptcha(ChromeDriver driver) {
        waitHelper.waitUntilVisibility(frame, 30);
        driver.switchTo().frame(frame);
        captchaButton.click();
        driver.switchTo().defaultContent();
        return this;
    }

    public RegisterPage clickOnRegisterButton() {
        registerButton.click();
        return this;
    }
}
