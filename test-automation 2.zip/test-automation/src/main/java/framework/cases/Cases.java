package framework.cases;

import framework.helpers.WaitHelper;
import framework.pages.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;

public class Cases extends BasePage {



    public Cases(ChromeDriver driver) {
        super(driver);
    }

//case 1

    @FindBy(xpath = "//*[text() = 'Web Tables']")
    private WebElement webTablesBtn;

    @FindBy(xpath = "//*[text() = 'Cierra']")
    private WebElement cierraText;


//case 2

    @FindBy(xpath = "//*[text() = 'Alex']")
    private WebElement alexText;


//case 3

    @FindBy(xpath = "//*[text() = 'Auto Complete']")
    private WebElement autoCompleteBtn;

    @FindBy(css = "[id = 'autoCompleteSingleInput'")
    private WebElement singleColorNameInput;

    @FindBy(xpath = "//*[text() = 'Red'][contains(@id, 'react-select')]")
    private WebElement selectRed;


//case 4

    @FindBy(css = "[id = 'autoCompleteMultipleInput'")
    private WebElement multipleColorNamesInput;

    @FindBy(xpath = "//*[text() = 'Blue'][contains(@id, 'react-select')]")
    private WebElement selectBlue;


//case 5

    @FindBy(xpath = "//*[text() = 'Tabs']")
    private WebElement tabsBtn;

    @FindBy(id = "demo-tab-what")
    private WebElement whatTab;

    @FindBy(id = "demo-tab-origin")
    private WebElement originTab;

    @FindBy(id = "demo-tab-use")
    private WebElement useTab;

    @FindBy(id = "demo-tab-more")
    private WebElement moreTab;

    @FindBy(xpath = "//*[@id='demo-tabpane-what']/p")
    private WebElement whatsText;

    @FindBy(xpath = "//*[@id='demo-tabpane-origin']/p")
    private WebElement originsText;

    @FindBy(xpath = "//*[@id='demo-tabpane-use']/p")
    private WebElement usesText;


//1
    public void clickOnWebTablesBtn() throws InterruptedException {
        webTablesBtn.click();
        WaitHelper.pause(3);
    }

    public boolean isCierraTextDisplayed() {
        return cierraText.isDisplayed();
    }

//2
    public boolean isAlexTextDisplayed() {
        return alexText.isDisplayed();
    }

//3
    public void clickOnAutoCompleteBtn() throws InterruptedException {
        autoCompleteBtn.click();
        WaitHelper.pause(3);
    }

    public void setSingleColorNameInputRed(String singleColorNameRed) {
        singleColorNameInput.sendKeys(singleColorNameRed);
    }

    public void selectRedForSingle() {
        waitHelper.waitUntilVisibility(selectRed);
        selectRed.click();
    }

//4
    public void setMultipleColorNamesInputRed(String multipleColorNamesRed) {
        multipleColorNamesInput.sendKeys(multipleColorNamesRed);
    }

    public void setMultipleColorNamesInputBlue(String multipleColorNamesBlue) {
        multipleColorNamesInput.sendKeys(multipleColorNamesBlue);
    }

    public void selectRedForMultiple() {
        waitHelper.waitUntilVisibility(selectRed);
        selectRed.click();
    }

    public void selectBlueForMultiple() {
        waitHelper.waitUntilVisibility(selectBlue);
        selectBlue.click();
    }

//5
    public void clickOnTabsBtn() {
        waitHelper.waitUntilVisibility(tabsBtn);
        waitHelper.waitUntilClickable(tabsBtn);
        tabsBtn.click();
    }

    public void clickOnWhatTab() {
        whatTab.click();
    }

    public int lengthOfWhatTab() {
        return whatsText.getText().length();
    }

    public void clickOnOriginTab() {
        originTab.click();
    }

    public int lengthOfOriginTab() {
        return originsText.getText().length();
    }

    public void clickOnUseTab() {
        useTab.click();
    }

    public int lengthOfUseTab() {
        return usesText.getText().length();
    }

    public void clickOnMoreTab() {
        moreTab.click();
    }

    public boolean isMoreTabEnable() throws InterruptedException {
        WaitHelper.pause(5);
        return moreTab.isEnabled();
    }
}
