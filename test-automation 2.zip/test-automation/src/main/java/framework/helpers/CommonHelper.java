package framework.helpers;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.security.Key;

public class CommonHelper {

    public static void moveToElement(Actions actions, WebElement webElement) {
        actions.moveToElement(webElement).perform();
    }

    public static void moveToElement(Actions actions, WebElement webElement, int x, int y) {
        actions.moveToElement(webElement, x, y).perform();
    }

    public static void doubleClick(Actions actions, WebElement webElement) {
        actions.doubleClick(webElement).perform();
    }

    public static void rightClick(Actions actions, WebElement webElement) {
        actions.contextClick(webElement).perform();
    }

    public static void aClick(Actions actions, WebElement webElement) {
        actions.click(webElement).perform();
    }

    public static void dragAndDrop(Actions actions, WebElement webElement) {
        actions.dragAndDrop(webElement, webElement).perform();
    }

    public static void dragAndDrop(Actions actions, WebElement webElement, int from, int to) {
        actions.dragAndDropBy(webElement, from, to).perform();
    }

    public static void shift(Actions actions, WebElement webElement, Keys keys) {
        actions.keyDown(webElement, keys.SHIFT).perform();
    }

    public static void control(Actions actions, WebElement webElement) {
        actions.keyDown(webElement, Keys.CONTROL).perform();
    }

    public static void command(Actions actions, WebElement webElement) {
        actions.keyDown(webElement, Keys.COMMAND).perform();
    }

    public static void backspace(Actions actions, WebElement webElement) {
        actions.keyDown(webElement, Keys.BACK_SPACE).perform();
    }

    public static void keyUp(Actions actions, Keys keys) {
        actions.keyUp(keys).perform();
    }

    public static void clickAndHold(Actions actions) {
        actions.clickAndHold().perform();
    }
}
